#!/usr/bin/python
import json
from flask import Flask, render_template, jsonify, request
import random

#WS
import RPi.GPIO as GPIO
import time
import board
import neopixel

import Adafruit_DHT

import requests
import json


import lcddriver
from time import *

app = Flask(__name__)


"""
Global Variablen
"""
fan_gpio_channel = 17
stripe_length = 60

fan_control = "OFF"
led_control = "OFF"

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(fan_gpio_channel, GPIO.OUT)


@app.route('/')
def index():
    temperatur, feuchtigkeit = dht22_luftfeuchtigkeit()
    temp = str(ds18b20_temp_sensor())
    print(temp)
    print(temperatur)
    print(feuchtigkeit)
    return render_template("index.html", temp=temp, temperatur=temperatur, feuchtigkeit=feuchtigkeit, fan_control=fan_control, led_control=led_control)

@app.route('/steuerung', methods=['GET','POST'])
def steuerung():
    if request.method == 'POST':

        if request.form.get("button1"):
            print("stripe_on")
            led_control = "ON"  # type: str
            stripe_on()
            # do something

        if request.form.get("button2"):
            print("stripe_off")
            led_control = "OFF"
            stripe_off()
            # do something

        #Color
        if request.form.get("button3"):
            print("white")
            led_control = "ON"
            stripe_white()


        if request.form.get("button4"):
            print("red")
            led_control = "ON"
            stripe_red()
            #pass

        if request.form.get("button5"):
            print("green")
            led_control = "ON"
            stripe_green()


        if request.form.get("button6"):
            print("blue")
            led_control = "ON"
            stripe_blue()


        #Fan Controll
        if request.form.get("button7"):
            print("fan_on")
            fan_control = "ON"
            fan_off(fan_gpio_channel)


        if request.form.get("button8"):
            print("fan_off")
            fan_control = "OFF"
            fan_on(fan_gpio_channel)



        return render_template('index.html')


    if request.method == 'GET':
        return render_template('index.html')

@app.route('/octoprint', methods=['GET','POST'])
def octoprint():
    IP_Adresse = "192.168.2.21"

    payload = {}
    headers = {
        'x-api-key': 'D9071CC139F34C6F8AC7CE6763324883'
    }

    """
    GET /api/job
    """
    job_URL = f"http://{IP_Adresse}/api/job"
    response = requests.get(job_URL, headers=headers, data=payload)
    job_json = response.json()
    job_sorted = json.dumps(job_json, indent=4)
    print(job_sorted)

    # Data
    estimatedPrintTime = json.dumps(job_json["job"]["estimatedPrintTime"])
    printTime = json.dumps(job_json["progress"]["printTime"])
    printTimeLeft = json.dumps(job_json["progress"]["printTimeLeft"])
    state = json.dumps(job_json["state"])
    print(estimatedPrintTime)
    print(printTime)
    print(printTimeLeft)
    print(state)

    """
    GET /api/printer
    """
    printer_URL = f"http://{IP_Adresse}/api/printer?history=true"
    response = requests.get(printer_URL, headers=headers, data=payload)
    printer_json = response.json()
    printer_sorted = json.dumps(printer_json, indent=4)
    print(printer_sorted)

    # Data
    temperature_nozzle_actual = json.dumps(printer_json["temperature"]["tool0"]["actual"])
    temperature_nozzle_target = json.dumps(printer_json["temperature"]["tool0"]["target"])
    temperature_bed_actual = json.dumps(printer_json["temperature"]["bed"]["actual"])
    temperatur_bed_target = json.dumps(printer_json["temperature"]["bed"]["target"])
    state_operational = json.dumps(printer_json["state"]["flags"]["operational"])
    state_printing = json.dumps(printer_json["state"]["flags"]["printing"])
    print(temperature_nozzle_actual)
    print(temperature_nozzle_target)
    print(temperature_bed_actual)
    print(temperatur_bed_target)
    print(state_operational)
    print(state_printing)
    return render_template("index.html", estimatedPrintTime = estimatedPrintTime, printTime = printTime, printTimeLeft = printTimeLeft, state = state, temperature_nozzle_actual = temperature_nozzle_actual, temperature_nozzle_target = temperature_nozzle_target, temperature_bed_actual = temperature_bed_actual, temperatur_bed_target = temperatur_bed_target, state_operational = state_operational, state_printing = state_printing)


"""
def index_alt():
    if request.method == 'POST':
        if request.form['submit_button1'] == 'Do Something':
            return render_template('index.html')
            # do something
        elif request.form['submit_button2'] == 'Do Something Else':
            print("test")
            #pass # do something else
        else:
            pass # unknown
    elif request.method == 'GET':
        return render_template('index.html')
"""





'''
WS2812 LED-Stripe
'''

def stripe_on():
    #Board-PIN, Anzahl der LEDs
    pixels = neopixel.NeoPixel(board.D18, stripe_length)

    #gesamter Streifen
    pixels.fill((252, 252, 252))
def stripe_off():
    # Turn them off.
    pixels = neopixel.NeoPixel(board.D18, stripe_length)
    pixels.fill((0,0,0))
    pixels.show()

def stripe_white():
    #Board-PIN, Anzahl der LEDs
    pixels = neopixel.NeoPixel(board.D18, stripe_length)

    #gesamter Streifen
    pixels.fill((252, 252, 252))

def stripe_red():
    #Board-PIN, Anzahl der LEDs
    pixels = neopixel.NeoPixel(board.D18, stripe_length)

    #gesamter Streifen
    pixels.fill((255, 0, 0))

def stripe_green():
    #Board-PIN, Anzahl der LEDs
    pixels = neopixel.NeoPixel(board.D18, stripe_length)

    #gesamter Streifen
    pixels.fill((0, 255, 0))

def stripe_blue():
    #Board-PIN, Anzahl der LEDs
    pixels = neopixel.NeoPixel(board.D18, stripe_length)

    #gesamter Streifen
    pixels.fill((0, 0, 255))


"""
Luefter
"""

def fan_on(pin):
    GPIO.output(pin, GPIO.HIGH)
    zustand = "FAN ON"
    print(zustand)

def fan_off(pin):
    GPIO.output(pin, GPIO.LOW)
    zustand = "FAN OFF"
    print(zustand)


"""
DHT-22 Luft- und Feuchtigkeitssensor
"""

def dht22_luftfeuchtigkeit():
    sensor = Adafruit_DHT.DHT22
    pin = 22
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
    temperatur = '{0:0.1f}'.format(temperature)
    feuchtigkeit = '{0:0.1f}%'.format(humidity)
    print("Temperatur_DHT22: ", temperatur)
    print("Feuchtigkeit_DHT22: ",feuchtigkeit)
    return (temperatur, feuchtigkeit)

"""
Temperatursensor
"""
def ds18b20_temp_sensor():
    file = open('/sys/bus/w1/devices/28-0416a0d4a1ff/w1_slave')
    filecontent = file.read()
    file.close()
    # Temperaturwerte auslesen und konvertieren
    stringvalue = filecontent.split("\n")[1].split(" ")[9]
    temperature = float(stringvalue[2:]) / 1000
    print("Temperatur_DS18b20:", temperature)
    # Temperatur ausgeben
    # rueckgabewert = '%6.2f' % temperature
    return (temperature)

"""
Display
"""

def display():
    lcd = lcddriver.lcd()
    lcd.lcd_clear()

    display.lcd_display_string("Temperatur_DHT22", 1)  # Write line of text to first line of display
    display.lcd_display_string(temperatur, 2)  # Write line of text to second line of display
    time.sleep(2)
    display.lcd_display_string("Feuchtigkeit_DHT22", 1)  # Give time for the message to be read
    display.lcd_display_string(feuchtigkeit, 2)
    time.sleep(2)
    display.lcd_display_string("Temperatur Gehaeuse", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(temp, 2)
    time.sleep(2)
    display.lcd_display_string("estimatedPrintTime", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(estimatedPrintTime, 2)
    time.sleep(2)
    display.lcd_display_string("printTime", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(printTime, 2)
    time.sleep(2)
    display.lcd_display_string("printTimeLeft", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(printTimeLeft, 2)
    time.sleep(2)
    display.lcd_display_string("state", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(state, 2)
    time.sleep(2)
    display.lcd_display_string("temperature_nozzle_actual",
                               1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(temperature_nozzle_actual, 2)
    time.sleep(2)
    display.lcd_display_string("temperature_nozzle_target",
                               1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(temperature_nozzle_target, 2)
    time.sleep(2)
    display.lcd_display_string("temperature_bed_actual", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(temperature_bed_actual, 2)
    time.sleep(2)
    display.lcd_display_string("temperatur_bed_target", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(temperatur_bed_target, 2)
    time.sleep(2)
    display.lcd_display_string("state_operational", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(state_operational, 2)
    time.sleep(2)
    display.lcd_display_string("state_printing", 1)  # Refresh the first line of display with a different mess$
    display.lcd_display_string(state_printing, 2)
    time.sleep(2)  # Give time for the message to be read
    display.lcd_clear()  # Clear the display of any data
    time.sleep(2)  # Give time for the message to be read




if __name__ == '__main__':
    app.run(host="192.168.2.22",port=1337, debug=True)
    display()
